# Billetera Clara

Mini sistema de finanzas personales en Scala 3 con interfaz Swing. Permite registrar ingresos y gastos, calcular el saldo, buscar movimientos, auditar el porcentaje de ocio y simular compras sin alterar los datos.

## Ejecutar

Requiere Java 17 o superior y Scala CLI. Desde esta carpeta:

```bash
scala run . --server=false --main-class billeteraclara.Main
```

También puedes ejecutar `sbt run`.

## Verificar el modelo

```bash
scala run src/main/scala src/test/scala --server=false --main-class billeteraclara.Verificacion
```

Los movimientos iniciales son de demostración. El botón **Empezar en blanco** limpia esos datos. La información se mantiene en memoria durante la sesión.
